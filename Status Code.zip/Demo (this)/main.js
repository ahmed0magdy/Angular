// var name = "Aly";
// var age = 25

// let obj = {
//     name:"Ahmed",
//     age:20,
//     display:function(){
//         return "Hello ya "+this.name+", of Age: "+this.age;
//     }
// }


// console.log(obj.display());

// let obj = {
//     name:"Ahmed",
//     age:20,
//     display:function(){
//         console.log(this);
//         var that = this;//_this   that   _that  self  _self
//         setTimeout(
//             function(){
//                 console.log("Hello ya "+that.name+", of Age: "+that.age)
//             },2000)
//     }
// }

// console.log(obj.display());


let obj = {
    name:"Ahmed",
    age:20,
    display:function(){
        setTimeout(
            ()=>{
                console.log("Hello ya "+this.name+", of Age: "+this.age)
            },2000)
    }
}

console.log(obj.display());


