import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { StudentsService } from 'src/app/Services/students.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styles: [
  ]
})
export class AddStudentComponent implements OnInit {

  constructor(private myService: StudentsService) { }

  ngOnInit(): void {
  }

  // addValidator = new FormGroup({
  //   name:new FormControl(,),
  //   age:new FormControl(,),
  //   email:new FormControl(,),
  // })

  AddStu(n:any, a:any, e:any){
    // console.log(n, a, e)
    this.myService.addNewStudent({name:n, age: a, email:e}).subscribe();
  }

}
