import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentsService {

  constructor(private myClient:HttpClient) { }

  private Base_URL = "http://localhost:3000/students";

  getAllStudents(){
    return this.myClient.get(this.Base_URL);
  }

  getStudentByID(id:number){
    return this.myClient.get(`${this.Base_URL}/${id}`);
  }

  addNewStudent(newStudent:any){
    return this.myClient.post(this.Base_URL, newStudent);
  }


  updateStudent(id:number, updatedStudent:any){
    return this.myClient.put(`${this.Base_URL}/${id}`,updatedStudent);
  }

  //delete
}
