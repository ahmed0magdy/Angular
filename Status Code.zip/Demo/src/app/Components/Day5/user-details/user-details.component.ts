import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DemoService } from 'src/app/Services/demo.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styles: [
  ]
})
export class UserDetailsComponent implements OnInit {
  userID = 0;
  user:any;//undefined
  constructor(private myActivated: ActivatedRoute, private myService: DemoService) {
    this.userID = myActivated.snapshot.params["id"];
   }

  ngOnInit(): void {//Fetch Data
    // console.log(this)
    let that = this;
    this.myService.getUserByID(this.userID).subscribe(
      {
        next(data){
          //console.log(data);
          // console.log(that);
          that.user = data;
        },
        error(err){console.log(err)}
      }
    )
  }

}
