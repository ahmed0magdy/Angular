import { Component, OnInit } from '@angular/core';
import { DemoService } from 'src/app/Services/demo.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styles: [
  ]
})
export class UsersComponent implements OnInit {

  constructor( public myService: DemoService ) { }

  users :any;
  ngOnInit(): void {//Fetching API
    // console.log(this.myService.getAllUsers())
    this.myService.getAllUsers().subscribe(
      (data)=>{
        //console.log(data)
        this.users = data;
      },
      (err)=>{console.log(err)}
    )
  }

}
