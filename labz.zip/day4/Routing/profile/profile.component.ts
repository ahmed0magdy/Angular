import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  name = "Ahmed Magdy"
  src = "https://img.freepik.com/premium-vector/young-man-avatar-character-vector-illustration-design_24877-18516.jpg?w=2000"
  age = 25
  para = "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Hic, sapiente. Necessitatibus rem autem reprehenderit, perferendis iure et minus mollitia doloremque consequatur voluptatem. Reiciendis quod maxime quam, maiores excepturi cum impedit numquam officia facere assumenda, voluptates aliquam laboriosam expedita quas ipsa veniam voluptatum ducimus esse aliquid architecto. Fugit numquam molestiae dolorem!"
}
