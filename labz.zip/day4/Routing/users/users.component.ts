import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }
  myRegFormValidation = new FormGroup({
    name: new FormControl("",[Validators.required,Validators.minLength(4),]),
    email:new FormControl("",[Validators.required,Validators.minLength(1),Validators.email]),
    age: new FormControl(0,[Validators.min(20), Validators.max(40),Validators.required])
  })




  get NameValid(){
    return this.myRegFormValidation.controls.name.valid
  }

  get EmailValid(){
    return this.myRegFormValidation.controls.email.valid;
  }

  get AgeValid(){
    return this.myRegFormValidation.controls.age.valid;
  }


  SendData(){
    console.log(this.myRegFormValidation);
    //Add Data To DB
    if(this.myRegFormValidation.valid){
      //ADD--->DB
    }
  }

}
