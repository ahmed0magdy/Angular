import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { UsersComponent } from './Routing/users/users.component';
import { UserDetailsComponent } from './Routing/user-details/user-details.component';
import { HeaderComponent } from './Routing/header/header.component';
import { ProfileComponent } from './Routing/profile/profile.component';
import { ErrorComponent } from './Routing/error/error.component';
import { RouterModule,Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


let routs:Routes =[
  {
    path:"users",component:UsersComponent
  },
  {
   path:"users/:id",component:UserDetailsComponent
  },
  {
    path:"profile",component:ProfileComponent
  },
  {
    path:"**",component:ErrorComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    HeaderComponent,
    ProfileComponent,
    ErrorComponent,
    UserDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routs)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
