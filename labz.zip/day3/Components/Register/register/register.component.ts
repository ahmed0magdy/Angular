import { Component, OnInit,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }
  name = "";
  age = 0;
  students: {name:string, age:number}[] = [];

 @Output() myEvent = new EventEmitter

  add(){
    let NewStudent:{name:string, age:number} = {name: this.name, age: this.age};
    if(this.age > 20 && this.age < 40 && this.name.length > 3 && this.name != "" && this.age != 0)
    this.students.push(NewStudent);
    this.myEvent.emit((this.students));



  }
}
