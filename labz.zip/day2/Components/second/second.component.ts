import { Component } from '@angular/core';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent {
  array:any = ["1.jpg","2.jpg","3.jpg","4.jpg"]
  src = "assets/images/1.jpg"
  index = 0;

    next(){
      if(this.index != (this.array.length -1)){
        this.src="assets/images/";
        this.index++;
        this.src  += this.array[this.index];
      }

    }
    previous(){
      if(this.index !=0){
        this.src = "assets/images/";
        this.index--;
        this.src  += this.array[this.index];
      }
    }
    slide(){

        this.index = 0;
        this.src = "assets/images/";
        this.src  += this.array[this.index];
        setInterval(()=>{
          if(this.index ==(this.array.length-1)){
            this.index = -1;
          }
          this.next();
        },500)

      }

    stop(){
      this.array = stop();
    }

}
