import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './First.Component.html',
  styleUrls: ['./First.Component.css']
})
export class FirstComponent {

  name = "";

  reset(){
    this.name = "";
  }
}
